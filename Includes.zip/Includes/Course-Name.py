# Databricks notebook source
# MAGIC 
# MAGIC %python
# MAGIC course_name = "Core Partner Enablement"